import { Beaker, Calendar, TrendingUp } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { FertilizerRecommendation } from "@/types";

interface FertilizerRecommendationsProps {
  fertilizers: FertilizerRecommendation[];
}

export function FertilizerRecommendations({ fertilizers }: FertilizerRecommendationsProps) {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Beaker className="w-6 h-6 text-secondary" />
        <h2 className="text-2xl font-bold">Fertilizer Recommendations</h2>
      </div>
      <p className="text-muted-foreground">
        Optimal fertilizers and application schedule for your selected crop
      </p>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {fertilizers.map((fertilizer) => (
          <Card key={fertilizer.name} className="shadow-elegant">
            <CardHeader>
              <div className="flex justify-between items-start">
                <CardTitle className="text-lg">{fertilizer.name}</CardTitle>
                <Badge variant="outline">{fertilizer.type}</Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-xs text-muted-foreground mb-1">NPK Ratio</div>
                  <div className="text-lg font-bold text-primary">{fertilizer.npkRatio}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground mb-1">Dosage</div>
                  <div className="text-sm font-semibold">{fertilizer.dosage}</div>
                </div>
              </div>

              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Calendar className="w-4 h-4 text-secondary" />
                  <span className="text-sm font-medium">Application Timing</span>
                </div>
                <div className="space-y-1">
                  {fertilizer.applicationTiming.map((timing, index) => (
                    <div
                      key={timing}
                      className="flex items-center gap-2 text-xs bg-muted px-3 py-2 rounded-md"
                    >
                      <span className="font-medium text-secondary">Stage {index + 1}:</span>
                      <span className="text-muted-foreground">{timing}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="w-4 h-4 text-primary" />
                  <span className="text-sm font-medium">Benefits</span>
                </div>
                <ul className="space-y-1">
                  {fertilizer.benefits.map((benefit) => (
                    <li key={benefit} className="text-xs text-muted-foreground flex items-start gap-2">
                      <span className="text-primary mt-0.5">•</span>
                      <span>{benefit}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
