import { Thermometer, Droplets, Cloud, Wind, MapPin } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type { WeatherData, SoilType } from "@/types";

interface EnvironmentalDataProps {
  weatherData: WeatherData;
  soilType: SoilType;
  locationName?: string;
}

export function EnvironmentalData({ weatherData, soilType, locationName }: EnvironmentalDataProps) {
  const displayLocation = locationName || weatherData.name;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h2 className="text-2xl font-bold">Environmental Conditions</h2>
        {displayLocation && (
          <div className="flex items-center gap-2 text-muted-foreground">
            <MapPin className="w-4 h-4" />
            <span className="text-sm font-medium">{displayLocation}</span>
          </div>
        )}
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        <Card className="shadow-elegant transition-smooth hover:shadow-glow">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Thermometer className="w-4 h-4 text-primary" />
              Temperature
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-primary">
              {weatherData.main.temp.toFixed(1)}°C
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Feels like {weatherData.main.feels_like.toFixed(1)}°C
            </p>
          </CardContent>
        </Card>

        <Card className="shadow-elegant transition-smooth hover:shadow-glow">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Droplets className="w-4 h-4 text-accent" />
              Humidity
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-accent">{weatherData.main.humidity}%</div>
            <p className="text-xs text-muted-foreground mt-1">
              {weatherData.main.humidity > 70 ? "High" : weatherData.main.humidity > 40 ? "Moderate" : "Low"} humidity
            </p>
          </CardContent>
        </Card>

        <Card className="shadow-elegant transition-smooth hover:shadow-glow">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Cloud className="w-4 h-4 text-secondary" />
              Rainfall
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-secondary">
              {weatherData.rain?.["1h"] ? `${weatherData.rain["1h"]}mm` : "0mm"}
            </div>
            <p className="text-xs text-muted-foreground mt-1">Last hour</p>
          </CardContent>
        </Card>

        <Card className="shadow-elegant transition-smooth hover:shadow-glow">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Wind className="w-4 h-4 text-primary" />
              Wind Speed
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-primary">
              {weatherData.wind.speed.toFixed(1)} m/s
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {weatherData.wind.speed > 10 ? "Strong" : weatherData.wind.speed > 5 ? "Moderate" : "Light"} wind
            </p>
          </CardContent>
        </Card>
      </div>

      <Card className="shadow-elegant">
        <CardHeader>
          <CardTitle className="text-lg">Soil Analysis</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div>
            <div className="flex justify-between items-center mb-1">
              <span className="text-sm font-medium">Soil Type</span>
              <span className="text-sm font-bold text-primary">{soilType.type}</span>
            </div>
            <p className="text-xs text-muted-foreground">{soilType.description}</p>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium">pH Level</span>
            <span className="text-sm font-bold text-primary">{soilType.ph}</span>
          </div>
          <div>
            <span className="text-sm font-medium">Key Nutrients</span>
            <div className="flex flex-wrap gap-2 mt-2">
              {soilType.nutrients.map((nutrient) => (
                <span
                  key={nutrient}
                  className="px-2 py-1 bg-primary/10 text-primary text-xs rounded-md"
                >
                  {nutrient}
                </span>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
