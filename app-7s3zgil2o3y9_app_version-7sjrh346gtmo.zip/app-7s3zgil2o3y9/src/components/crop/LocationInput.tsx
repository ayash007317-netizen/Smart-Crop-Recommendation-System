import { useState, useEffect } from "react";
import { MapPin, Navigation, Loader2, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { getLocationName } from "@/services/weatherService";
import type { LocationInfo } from "@/services/weatherService";

interface LocationInputProps {
  onLocationSelect: (latitude: number, longitude: number, cityName?: string) => void;
  isLoading: boolean;
}

export function LocationInput({ onLocationSelect, isLoading }: LocationInputProps) {
  const [manualLat, setManualLat] = useState("");
  const [manualLon, setManualLon] = useState("");
  const [cityName, setCityName] = useState("");
  const [detectedLocation, setDetectedLocation] = useState<LocationInfo | null>(null);
  const [isDetectingLocation, setIsDetectingLocation] = useState(false);
  const [gpsLoading, setGpsLoading] = useState(false);

  useEffect(() => {
    const detectLocation = async () => {
      const lat = Number.parseFloat(manualLat);
      const lon = Number.parseFloat(manualLon);

      if (!Number.isNaN(lat) && !Number.isNaN(lon) && lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180) {
        setIsDetectingLocation(true);
        try {
          const locationInfo = await getLocationName(lat, lon);
          setDetectedLocation(locationInfo);
          if (!cityName) {
            setCityName(locationInfo.name);
          }
        } catch (error) {
          setDetectedLocation(null);
        } finally {
          setIsDetectingLocation(false);
        }
      } else {
        setDetectedLocation(null);
      }
    };

    const timeoutId = setTimeout(detectLocation, 800);
    return () => clearTimeout(timeoutId);
  }, [manualLat, manualLon]);

  const handleGPSLocation = async () => {
    setGpsLoading(true);
    if (!navigator.geolocation) {
      alert("Geolocation is not supported by your browser");
      setGpsLoading(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const lat = position.coords.latitude;
        const lon = position.coords.longitude;
        
        try {
          const locationInfo = await getLocationName(lat, lon);
          onLocationSelect(lat, lon, locationInfo.displayName);
        } catch (error) {
          onLocationSelect(lat, lon);
        } finally {
          setGpsLoading(false);
        }
      },
      (error) => {
        alert(`Location error: ${error.message}`);
        setGpsLoading(false);
      }
    );
  };

  const handleManualSubmit = () => {
    const lat = Number.parseFloat(manualLat);
    const lon = Number.parseFloat(manualLon);

    if (Number.isNaN(lat) || Number.isNaN(lon)) {
      alert("Please enter valid latitude and longitude values");
      return;
    }

    if (lat < -90 || lat > 90) {
      alert("Latitude must be between -90 and 90");
      return;
    }

    if (lon < -180 || lon > 180) {
      alert("Longitude must be between -180 and 180");
      return;
    }

    const finalLocationName = cityName || detectedLocation?.displayName;
    onLocationSelect(lat, lon, finalLocationName);
  };

  return (
    <Card className="shadow-elegant">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MapPin className="w-5 h-5 text-primary" />
          Location Selection
        </CardTitle>
        <CardDescription>
          Choose your location to get personalized crop recommendations
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-3">
          <Button
            onClick={handleGPSLocation}
            disabled={isLoading || gpsLoading}
            className="w-full"
            size="lg"
          >
            {gpsLoading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Detecting Location...
              </>
            ) : (
              <>
                <Navigation className="w-4 h-4 mr-2" />
                Use My Current Location
              </>
            )}
          </Button>
        </div>

        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <span className="w-full border-t border-border" />
          </div>
          <div className="relative flex justify-center text-xs uppercase">
            <span className="bg-card px-2 text-muted-foreground">Or enter manually</span>
          </div>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="cityName">City / Village Name (Optional)</Label>
            <Input
              id="cityName"
              type="text"
              placeholder="e.g., New Delhi, Mumbai, or your village name"
              value={cityName}
              onChange={(e) => setCityName(e.target.value)}
              disabled={isLoading}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="latitude">Latitude</Label>
            <Input
              id="latitude"
              type="number"
              placeholder="e.g., 28.6139"
              value={manualLat}
              onChange={(e) => setManualLat(e.target.value)}
              step="0.0001"
              disabled={isLoading}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="longitude">Longitude</Label>
            <Input
              id="longitude"
              type="number"
              placeholder="e.g., 77.2090"
              value={manualLon}
              onChange={(e) => setManualLon(e.target.value)}
              step="0.0001"
              disabled={isLoading}
            />
          </div>

          {(isDetectingLocation || detectedLocation) && (
            <div className="rounded-lg border border-border bg-muted/50 p-3">
              <div className="flex items-start gap-2">
                {isDetectingLocation ? (
                  <>
                    <Search className="mt-0.5 h-4 w-4 animate-pulse text-muted-foreground" />
                    <div className="flex-1">
                      <p className="text-sm text-muted-foreground">Detecting location...</p>
                    </div>
                  </>
                ) : detectedLocation ? (
                  <>
                    <MapPin className="mt-0.5 h-4 w-4 text-primary" />
                    <div className="flex-1">
                      <p className="text-sm font-medium">Detected Location</p>
                      <p className="text-xs text-muted-foreground">{detectedLocation.displayName}</p>
                    </div>
                  </>
                ) : null}
              </div>
            </div>
          )}

          <Button
            onClick={handleManualSubmit}
            disabled={isLoading || !manualLat || !manualLon}
            className="w-full"
            variant="secondary"
          >
            Get Recommendations
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
