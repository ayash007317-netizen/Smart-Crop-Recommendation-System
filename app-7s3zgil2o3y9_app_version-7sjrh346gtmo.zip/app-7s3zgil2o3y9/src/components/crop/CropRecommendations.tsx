import { Sprout, Calendar, Droplet, Thermometer, CheckCircle2 } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import type { CropRecommendation } from "@/types";

interface CropRecommendationsProps {
  crops: CropRecommendation[];
  onCropSelect: (crop: CropRecommendation) => void;
  selectedCrop?: CropRecommendation;
}

export function CropRecommendations({
  crops,
  onCropSelect,
  selectedCrop,
}: CropRecommendationsProps) {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Sprout className="w-6 h-6 text-primary" />
        <h2 className="text-2xl font-bold">Recommended Crops</h2>
      </div>
      <p className="text-muted-foreground">
        Based on your location's environmental conditions, here are the best crops for cultivation
      </p>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {crops.map((crop) => (
          <Card
            key={crop.name}
            className={`shadow-elegant transition-smooth cursor-pointer hover:shadow-glow ${
              selectedCrop?.name === crop.name ? "ring-2 ring-primary" : ""
            }`}
            onClick={() => onCropSelect(crop)}
          >
            <CardHeader>
              <div className="flex justify-between items-start">
                <div className="space-y-1">
                  <CardTitle className="text-xl">{crop.name}</CardTitle>
                  <CardDescription className="italic">{crop.scientificName}</CardDescription>
                </div>
                <Badge
                  variant={crop.suitabilityScore >= 90 ? "default" : "secondary"}
                  className="text-sm"
                >
                  {crop.suitabilityScore}% Match
                </Badge>
              </div>
              <Progress value={crop.suitabilityScore} className="h-2 mt-2" />
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">{crop.description}</p>

              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="flex items-start gap-2">
                  <Calendar className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                  <div>
                    <div className="font-medium">Season</div>
                    <div className="text-muted-foreground text-xs">{crop.growingSeason}</div>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <Droplet className="w-4 h-4 text-accent mt-0.5 shrink-0" />
                  <div>
                    <div className="font-medium">Water Need</div>
                    <div className="text-muted-foreground text-xs">{crop.waterRequirement}</div>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <Thermometer className="w-4 h-4 text-secondary mt-0.5 shrink-0" />
                  <div>
                    <div className="font-medium">Temperature</div>
                    <div className="text-muted-foreground text-xs">{crop.temperatureRange}</div>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <Sprout className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                  <div>
                    <div className="font-medium">Soil Type</div>
                    <div className="text-muted-foreground text-xs">{crop.soilType.join(", ")}</div>
                  </div>
                </div>
              </div>

              <div>
                <div className="font-medium text-sm mb-2">Key Benefits</div>
                <div className="space-y-1">
                  {crop.benefits.map((benefit) => (
                    <div key={benefit} className="flex items-start gap-2 text-xs">
                      <CheckCircle2 className="w-3 h-3 text-primary mt-0.5 shrink-0" />
                      <span className="text-muted-foreground">{benefit}</span>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
