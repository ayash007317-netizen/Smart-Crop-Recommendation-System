import { Droplets, Clock, Waves, Calendar } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type { IrrigationSchedule } from "@/types";

interface IrrigationScheduleProps {
  schedule: IrrigationSchedule;
}

export function IrrigationScheduleComponent({ schedule }: IrrigationScheduleProps) {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Droplets className="w-6 h-6 text-accent" />
        <h2 className="text-2xl font-bold">Irrigation Schedule</h2>
      </div>
      <p className="text-muted-foreground">
        Customized watering plan based on crop requirements and local climate
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="shadow-elegant">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Clock className="w-4 h-4 text-accent" />
              Frequency
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-accent">{schedule.frequency}</div>
            <p className="text-xs text-muted-foreground mt-2">
              Adjust based on rainfall and soil moisture
            </p>
          </CardContent>
        </Card>

        <Card className="shadow-elegant">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Droplets className="w-4 h-4 text-accent" />
              Water Amount
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-accent">{schedule.amount}</div>
            <p className="text-xs text-muted-foreground mt-2">Per irrigation session</p>
          </CardContent>
        </Card>

        <Card className="shadow-elegant">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Waves className="w-4 h-4 text-accent" />
              Irrigation Method
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-lg font-semibold text-accent">{schedule.method}</div>
            <p className="text-xs text-muted-foreground mt-2">
              Recommended for optimal water efficiency
            </p>
          </CardContent>
        </Card>

        <Card className="shadow-elegant">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Clock className="w-4 h-4 text-accent" />
              Best Timing
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {schedule.timing.map((time) => (
                <div
                  key={time}
                  className="bg-accent/10 text-accent px-3 py-2 rounded-md text-sm font-medium"
                >
                  {time}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="shadow-elegant">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Calendar className="w-4 h-4 text-accent" />
            Seasonal Adjustments
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">{schedule.seasonalAdjustments}</p>
        </CardContent>
      </Card>
    </div>
  );
}
