import { TrendingUp, BarChart3, Target } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import type { YieldPrediction } from "@/types";

interface YieldPredictionProps {
  prediction: YieldPrediction;
}

export function YieldPredictionComponent({ prediction }: YieldPredictionProps) {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <TrendingUp className="w-6 h-6 text-primary" />
        <h2 className="text-2xl font-bold">Yield Prediction</h2>
      </div>
      <p className="text-muted-foreground">
        Estimated crop yield based on environmental conditions and best practices
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="shadow-elegant md:col-span-2">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-primary" />
              Estimated Yield
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-baseline gap-2">
              <span className="text-4xl font-bold text-primary">{prediction.estimatedYield}</span>
              <span className="text-xl text-muted-foreground">{prediction.unit}</span>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-elegant md:col-span-2">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Target className="w-4 h-4 text-primary" />
              Confidence Level
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-2xl font-bold text-primary">{prediction.confidence}%</span>
              <span className="text-sm text-muted-foreground">
                {prediction.confidence >= 90
                  ? "Very High"
                  : prediction.confidence >= 80
                    ? "High"
                    : "Moderate"}
              </span>
            </div>
            <Progress value={prediction.confidence} className="h-3" />
          </CardContent>
        </Card>
      </div>

      <Card className="shadow-elegant">
        <CardHeader>
          <CardTitle className="text-base">Yield Factors</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {prediction.factors.map((factor) => (
              <div
                key={factor.name}
                className="flex justify-between items-center p-3 bg-muted rounded-md"
              >
                <span className="text-sm font-medium">{factor.name}</span>
                <span className="text-sm font-bold text-primary">{factor.impact}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 p-3 bg-primary/10 rounded-md">
            <p className="text-xs text-muted-foreground">
              <strong>Note:</strong> Actual yields may vary based on farming practices, pest
              management, and weather variations. These predictions are based on optimal conditions
              and historical data.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
