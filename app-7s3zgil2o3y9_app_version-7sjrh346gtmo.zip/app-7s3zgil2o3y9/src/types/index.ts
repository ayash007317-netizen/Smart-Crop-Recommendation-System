export interface Option {
  label: string;
  value: string;
  icon?: React.ComponentType<{ className?: string }>;
  withCount?: boolean;
}

export interface WeatherData {
  coord: {
    lon: number;
    lat: number;
  };
  weather: Array<{
    id: number;
    main: string;
    description: string;
    icon: string;
  }>;
  main: {
    temp: number;
    feels_like: number;
    temp_min: number;
    temp_max: number;
    pressure: number;
    humidity: number;
  };
  wind: {
    speed: number;
    deg: number;
  };
  rain?: {
    "1h": number;
  };
  clouds: {
    all: number;
  };
  dt: number;
  sys: {
    country: string;
    sunrise: number;
    sunset: number;
  };
  timezone: number;
  id: number;
  name: string;
}

export interface LocationData {
  latitude: number;
  longitude: number;
  city?: string;
  pincode?: string;
}

export interface SoilType {
  type: string;
  description: string;
  ph: number;
  nutrients: string[];
}

export interface CropRecommendation {
  name: string;
  scientificName: string;
  suitabilityScore: number;
  growingSeason: string;
  waterRequirement: string;
  soilType: string[];
  temperatureRange: string;
  description: string;
  benefits: string[];
}

export interface FertilizerRecommendation {
  name: string;
  type: string;
  npkRatio: string;
  dosage: string;
  applicationTiming: string[];
  benefits: string[];
}

export interface IrrigationSchedule {
  frequency: string;
  amount: string;
  method: string;
  timing: string[];
  seasonalAdjustments: string;
}

export interface YieldPrediction {
  estimatedYield: string;
  unit: string;
  confidence: number;
  factors: Array<{
    name: string;
    impact: string;
  }>;
}
