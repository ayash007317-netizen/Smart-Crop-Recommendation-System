import { useState } from "react";
import { Sprout, Loader2 } from "lucide-react";
import { LocationInput } from "@/components/crop/LocationInput";
import { EnvironmentalData } from "@/components/crop/EnvironmentalData";
import { CropRecommendations } from "@/components/crop/CropRecommendations";
import { FertilizerRecommendations } from "@/components/crop/FertilizerRecommendations";
import { IrrigationScheduleComponent } from "@/components/crop/IrrigationSchedule";
import { YieldPredictionComponent } from "@/components/crop/YieldPrediction";
import { getWeatherData } from "@/services/weatherService";
import {
  determineSoilType,
  getCropRecommendations,
  getFertilizerRecommendations,
  getIrrigationSchedule,
  predictYield,
} from "@/services/cropRecommendationService";
import type {
  WeatherData,
  SoilType,
  CropRecommendation,
  FertilizerRecommendation,
  IrrigationSchedule,
  YieldPrediction,
} from "@/types";
import { useToast } from "@/hooks/use-toast";

export default function Home() {
  const [isLoading, setIsLoading] = useState(false);
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null);
  const [soilType, setSoilType] = useState<SoilType | null>(null);
  const [crops, setCrops] = useState<CropRecommendation[]>([]);
  const [selectedCrop, setSelectedCrop] = useState<CropRecommendation | null>(null);
  const [fertilizers, setFertilizers] = useState<FertilizerRecommendation[]>([]);
  const [irrigation, setIrrigation] = useState<IrrigationSchedule | null>(null);
  const [yieldPrediction, setYieldPrediction] = useState<YieldPrediction | null>(null);
  const [locationName, setLocationName] = useState<string>("");
  const { toast } = useToast();

  const handleLocationSelect = async (latitude: number, longitude: number, cityName?: string) => {
    setIsLoading(true);
    setLocationName(cityName || "");
    try {
      const weather = await getWeatherData(latitude, longitude);
      setWeatherData(weather);

      const rainfall = weather.rain?.["1h"] || 0;
      const soil = determineSoilType(weather.main.temp, weather.main.humidity, rainfall);
      setSoilType(soil);

      const cropRecommendations = getCropRecommendations(weather, soil);
      setCrops(cropRecommendations);

      if (cropRecommendations.length > 0) {
        const topCrop = cropRecommendations[0];
        setSelectedCrop(topCrop);
        setFertilizers(getFertilizerRecommendations(topCrop, soil));
        setIrrigation(getIrrigationSchedule(topCrop, weather));
        setYieldPrediction(predictYield(topCrop, weather, soil));
      }

      toast({
        title: "Success",
        description: `Recommendations generated for ${cityName || weather.name}`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to fetch data",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCropSelect = (crop: CropRecommendation) => {
    setSelectedCrop(crop);
    if (weatherData && soilType) {
      setFertilizers(getFertilizerRecommendations(crop, soilType));
      setIrrigation(getIrrigationSchedule(crop, weatherData));
      setYieldPrediction(predictYield(crop, weatherData, soilType));
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="@container">
        <header className="border-b border-border bg-card shadow-sm">
          <div className="max-w-7xl mx-auto px-4 py-6 @md:px-6 @lg:px-8">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-primary/10 rounded-lg">
                <Sprout className="w-8 h-8 text-primary" />
              </div>
              <div>
                <h1 className="text-3xl max-sm:text-2xl font-bold gradient-text">
                  Smart Crop Recommendation System
                </h1>
                <p className="text-sm text-muted-foreground mt-1">
                  AI-powered agricultural guidance for optimal crop selection
                </p>
              </div>
            </div>
          </div>
        </header>

        <main className="max-w-7xl mx-auto px-4 py-8 @md:px-6 @lg:px-8">
          <div className="space-y-8">
            {!weatherData ? (
              <div className="max-w-2xl mx-auto">
                <LocationInput onLocationSelect={handleLocationSelect} isLoading={isLoading} />
                {isLoading && (
                  <div className="mt-8 flex flex-col items-center justify-center gap-4">
                    <Loader2 className="w-12 h-12 animate-spin text-primary" />
                    <p className="text-muted-foreground">Analyzing environmental conditions...</p>
                  </div>
                )}
              </div>
            ) : (
              <>
                {weatherData && soilType && (
                  <EnvironmentalData 
                    weatherData={weatherData} 
                    soilType={soilType}
                    locationName={locationName}
                  />
                )}

                {crops.length > 0 && (
                  <CropRecommendations
                    crops={crops}
                    onCropSelect={handleCropSelect}
                    selectedCrop={selectedCrop || undefined}
                  />
                )}

                {selectedCrop && (
                  <>
                    {fertilizers.length > 0 && (
                      <FertilizerRecommendations fertilizers={fertilizers} />
                    )}

                    {irrigation && <IrrigationScheduleComponent schedule={irrigation} />}

                    {yieldPrediction && <YieldPredictionComponent prediction={yieldPrediction} />}
                  </>
                )}

                <div className="flex justify-center pt-4">
                  <button
                    type="button"
                    onClick={() => {
                      setWeatherData(null);
                      setSoilType(null);
                      setCrops([]);
                      setSelectedCrop(null);
                      setFertilizers([]);
                      setIrrigation(null);
                      setYieldPrediction(null);
                      setLocationName("");
                    }}
                    className="px-6 py-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-smooth"
                  >
                    ← Change Location
                  </button>
                </div>
              </>
            )}
          </div>
        </main>

        <footer className="border-t border-border bg-card mt-16">
          <div className="max-w-7xl mx-auto px-4 py-6 @md:px-6 @lg:px-8">
            <p className="text-center text-sm text-muted-foreground">
              2025 Smart Crop Recommendation System
            </p>
          </div>
        </footer>
      </div>
    </div>
  );
}
