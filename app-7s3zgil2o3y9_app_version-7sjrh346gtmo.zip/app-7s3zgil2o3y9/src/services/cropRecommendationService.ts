import type {
  WeatherData,
  SoilType,
  CropRecommendation,
  FertilizerRecommendation,
  IrrigationSchedule,
  YieldPrediction,
} from "@/types";

export function determineSoilType(temperature: number, humidity: number, rainfall: number): SoilType {
  if (humidity > 70 && rainfall > 50) {
    return {
      type: "Clay Loam",
      description: "Rich, moisture-retentive soil ideal for rice and vegetables",
      ph: 6.5,
      nutrients: ["Nitrogen", "Phosphorus", "Potassium", "Organic Matter"],
    };
  }
  if (temperature > 25 && humidity < 50) {
    return {
      type: "Sandy Loam",
      description: "Well-draining soil suitable for root vegetables and legumes",
      ph: 6.8,
      nutrients: ["Phosphorus", "Potassium", "Calcium"],
    };
  }
  if (temperature < 20 && humidity > 60) {
    return {
      type: "Silt Loam",
      description: "Fertile soil perfect for wheat and barley",
      ph: 7.0,
      nutrients: ["Nitrogen", "Phosphorus", "Organic Matter"],
    };
  }
  return {
    type: "Loamy Soil",
    description: "Balanced soil suitable for most crops",
    ph: 6.8,
    nutrients: ["Nitrogen", "Phosphorus", "Potassium"],
  };
}

export function getCropRecommendations(
  weatherData: WeatherData,
  soilType: SoilType
): CropRecommendation[] {
  const temp = weatherData.main.temp;
  const humidity = weatherData.main.humidity;
  const rainfall = weatherData.rain?.["1h"] || 0;
  const recommendations: CropRecommendation[] = [];

  if (temp >= 20 && temp <= 35 && humidity > 60) {
    recommendations.push({
      name: "Rice",
      scientificName: "Oryza sativa",
      suitabilityScore: 95,
      growingSeason: "Monsoon (June-November)",
      waterRequirement: "High (1500-2000mm)",
      soilType: ["Clay Loam", "Silt Loam"],
      temperatureRange: "20-35°C",
      description: "Staple crop requiring flooded conditions and warm temperatures",
      benefits: ["High yield potential", "Suitable for wet conditions", "Good market demand"],
    });
  }

  if (temp >= 15 && temp <= 25 && humidity < 70) {
    recommendations.push({
      name: "Wheat",
      scientificName: "Triticum aestivum",
      suitabilityScore: 90,
      growingSeason: "Winter (November-April)",
      waterRequirement: "Medium (450-650mm)",
      soilType: ["Loamy Soil", "Silt Loam"],
      temperatureRange: "15-25°C",
      description: "Cool season crop ideal for winter cultivation",
      benefits: ["Drought tolerant", "High nutritional value", "Excellent storage life"],
    });
  }

  if (temp >= 25 && temp <= 35 && humidity < 60) {
    recommendations.push({
      name: "Cotton",
      scientificName: "Gossypium",
      suitabilityScore: 88,
      growingSeason: "Summer (April-October)",
      waterRequirement: "Medium (700-1300mm)",
      soilType: ["Sandy Loam", "Loamy Soil"],
      temperatureRange: "25-35°C",
      description: "Cash crop requiring warm weather and moderate rainfall",
      benefits: ["High economic value", "Multiple harvests", "Good fiber quality"],
    });
  }

  if (temp >= 20 && temp <= 30) {
    recommendations.push({
      name: "Maize (Corn)",
      scientificName: "Zea mays",
      suitabilityScore: 85,
      growingSeason: "Summer (March-September)",
      waterRequirement: "Medium (500-800mm)",
      soilType: ["Loamy Soil", "Sandy Loam"],
      temperatureRange: "20-30°C",
      description: "Versatile crop suitable for various climatic conditions",
      benefits: ["Fast growing", "Multiple uses", "Good yield"],
    });
  }

  if (temp >= 15 && temp <= 28 && humidity > 50) {
    recommendations.push({
      name: "Sugarcane",
      scientificName: "Saccharum officinarum",
      suitabilityScore: 82,
      growingSeason: "Year-round (12-18 months)",
      waterRequirement: "High (1500-2500mm)",
      soilType: ["Clay Loam", "Loamy Soil"],
      temperatureRange: "15-28°C",
      description: "Long-duration crop requiring consistent moisture",
      benefits: ["High sugar content", "Multiple products", "Good income"],
    });
  }

  if (temp >= 18 && temp <= 30) {
    recommendations.push({
      name: "Soybean",
      scientificName: "Glycine max",
      suitabilityScore: 80,
      growingSeason: "Monsoon (June-October)",
      waterRequirement: "Medium (450-700mm)",
      soilType: ["Loamy Soil", "Sandy Loam"],
      temperatureRange: "18-30°C",
      description: "Protein-rich legume crop with nitrogen-fixing properties",
      benefits: ["Soil enrichment", "High protein", "Good market value"],
    });
  }

  return recommendations.sort((a, b) => b.suitabilityScore - a.suitabilityScore).slice(0, 4);
}

export function getFertilizerRecommendations(
  crop: CropRecommendation,
  soilType: SoilType
): FertilizerRecommendation[] {
  const recommendations: FertilizerRecommendation[] = [];

  if (crop.name === "Rice") {
    recommendations.push(
      {
        name: "Urea",
        type: "Nitrogen",
        npkRatio: "46-0-0",
        dosage: "120-150 kg/hectare",
        applicationTiming: ["Basal (20%)", "Tillering (40%)", "Panicle initiation (40%)"],
        benefits: ["Promotes vegetative growth", "Increases grain yield", "Enhances protein content"],
      },
      {
        name: "DAP (Diammonium Phosphate)",
        type: "Phosphorus",
        npkRatio: "18-46-0",
        dosage: "50-60 kg/hectare",
        applicationTiming: ["Basal application"],
        benefits: ["Root development", "Early plant vigor", "Grain formation"],
      }
    );
  } else if (crop.name === "Wheat") {
    recommendations.push(
      {
        name: "NPK Complex",
        type: "Balanced",
        npkRatio: "12-32-16",
        dosage: "100-120 kg/hectare",
        applicationTiming: ["Basal application", "Crown root initiation"],
        benefits: ["Balanced nutrition", "Strong root system", "Better tillering"],
      },
      {
        name: "Urea",
        type: "Nitrogen",
        npkRatio: "46-0-0",
        dosage: "80-100 kg/hectare",
        applicationTiming: ["Crown root stage", "Jointing stage"],
        benefits: ["Leaf development", "Grain filling", "Protein enhancement"],
      }
    );
  } else {
    recommendations.push(
      {
        name: "NPK Complex",
        type: "Balanced",
        npkRatio: "10-26-26",
        dosage: "100-150 kg/hectare",
        applicationTiming: ["Basal application", "30 days after sowing"],
        benefits: ["Overall plant health", "Balanced growth", "Disease resistance"],
      },
      {
        name: "Organic Compost",
        type: "Organic",
        npkRatio: "Variable",
        dosage: "5-10 tons/hectare",
        applicationTiming: ["Pre-sowing soil preparation"],
        benefits: ["Soil structure improvement", "Microbial activity", "Long-term fertility"],
      }
    );
  }

  return recommendations;
}

export function getIrrigationSchedule(
  crop: CropRecommendation,
  weatherData: WeatherData
): IrrigationSchedule {
  const rainfall = weatherData.rain?.["1h"] || 0;
  const humidity = weatherData.main.humidity;

  if (crop.waterRequirement === "High (1500-2000mm)" || crop.waterRequirement.includes("High")) {
    return {
      frequency: rainfall > 10 ? "Every 3-4 days" : "Every 2-3 days",
      amount: "50-75mm per irrigation",
      method: "Flood irrigation or Drip irrigation",
      timing: ["Early morning (6-8 AM)", "Late evening (5-7 PM)"],
      seasonalAdjustments: "Increase frequency during flowering and grain filling stages",
    };
  }

  if (crop.waterRequirement.includes("Medium")) {
    return {
      frequency: rainfall > 5 ? "Every 5-7 days" : "Every 4-5 days",
      amount: "30-50mm per irrigation",
      method: "Sprinkler or Drip irrigation",
      timing: ["Early morning (6-8 AM)"],
      seasonalAdjustments: "Reduce frequency during rainy season, increase during dry spells",
    };
  }

  return {
    frequency: "Every 7-10 days",
    amount: "20-30mm per irrigation",
    method: "Drip irrigation recommended",
    timing: ["Early morning (6-8 AM)"],
    seasonalAdjustments: "Minimal irrigation during monsoon, critical during flowering",
  };
}

export function predictYield(
  crop: CropRecommendation,
  weatherData: WeatherData,
  soilType: SoilType
): YieldPrediction {
  const baseYields: Record<string, number> = {
    Rice: 4500,
    Wheat: 3500,
    Cotton: 2000,
    "Maize (Corn)": 5000,
    Sugarcane: 70000,
    Soybean: 2500,
  };

  const baseYield = baseYields[crop.name] || 3000;
  let yieldMultiplier = 1.0;
  const factors: Array<{ name: string; impact: string }> = [];

  const temp = weatherData.main.temp;
  const humidity = weatherData.main.humidity;

  if (crop.suitabilityScore >= 90) {
    yieldMultiplier *= 1.15;
    factors.push({ name: "Optimal conditions", impact: "+15%" });
  } else if (crop.suitabilityScore >= 80) {
    yieldMultiplier *= 1.08;
    factors.push({ name: "Good conditions", impact: "+8%" });
  }

  if (soilType.ph >= 6.5 && soilType.ph <= 7.5) {
    yieldMultiplier *= 1.05;
    factors.push({ name: "Ideal soil pH", impact: "+5%" });
  }

  if (humidity >= 50 && humidity <= 70) {
    yieldMultiplier *= 1.03;
    factors.push({ name: "Optimal humidity", impact: "+3%" });
  }

  const estimatedYield = Math.round(baseYield * yieldMultiplier);
  const confidence = Math.min(95, crop.suitabilityScore + 5);

  return {
    estimatedYield: estimatedYield.toLocaleString(),
    unit: crop.name === "Sugarcane" ? "kg/hectare" : "kg/hectare",
    confidence,
    factors,
  };
}
