import type { WeatherData } from "@/types";

const WEATHER_API_URL = "https://api-integrations.appmedo.com/app-7s3zgil2o3y9/api-rY7J6E5obXeL/data/2.5/weather";
const GEOCODING_API_URL = "https://api-integrations.appmedo.com/app-7s3zgil2o3y9/api-rY7J6E5obXeL/geo/1.0/reverse";
const API_KEY = "ee78c39e8ee2f4843ec15b1507c93b55";

export interface LocationInfo {
  name: string;
  state?: string;
  country: string;
  displayName: string;
}

export async function getLocationName(lat: number, lon: number): Promise<LocationInfo> {
  try {
    const url = new URL(GEOCODING_API_URL);
    url.searchParams.append("lat", lat.toString());
    url.searchParams.append("lon", lon.toString());
    url.searchParams.append("limit", "1");
    url.searchParams.append("appid", API_KEY);

    const response = await fetch(url.toString(), {
      method: "GET",
      headers: {
        Accept: "application/json",
      },
    });

    if (!response.ok) {
      throw new Error(`Geocoding API error: ${response.statusText}`);
    }

    const data = await response.json();
    
    if (!data || data.length === 0) {
      throw new Error("Location not found");
    }

    const location = data[0];
    const displayName = location.state 
      ? `${location.name}, ${location.state}, ${location.country}`
      : `${location.name}, ${location.country}`;

    return {
      name: location.name,
      state: location.state,
      country: location.country,
      displayName,
    };
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error("Failed to fetch location information");
  }
}

export async function getWeatherData(lat: number, lon: number): Promise<WeatherData> {
  try {
    const url = new URL(WEATHER_API_URL);
    url.searchParams.append("lat", lat.toString());
    url.searchParams.append("lon", lon.toString());
    url.searchParams.append("appid", API_KEY);
    url.searchParams.append("units", "metric");

    const response = await fetch(url.toString(), {
      method: "GET",
      headers: {
        Accept: "application/json",
      },
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      if (errorData.status === 999) {
        throw new Error(errorData.msg || "Weather API error");
      }
      throw new Error(`Weather API error: ${response.statusText}`);
    }

    const data = await response.json();
    return data;
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error("Failed to fetch weather data");
  }
}

export async function getCurrentLocation(): Promise<{ latitude: number; longitude: number }> {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error("Geolocation is not supported by your browser"));
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
        });
      },
      (error) => {
        reject(new Error(`Location error: ${error.message}`));
      }
    );
  });
}
